This file is part of metadata profile of ISO 19115 for INSPIRE Spatial Data Services.
Schema version 1.0.0

srv folder contains the schemas files taken from http://schemas.opengis.net/iso/19139/20060504/srv/
and edited to point to gmd schemas 2007 version http://schemas.opengis.net/iso/19139/20070417/